Linia 1 : Numero de problemas
1 Integer

Linia 2 : Numero de peticiones
1 Integer

Linia 3 : Distribucion de capacidad de los camiones
3 Integers para 500, 1000 y 2000kg
La suma de los 3 debe ser igual a 60.

Linia 4 : Distribucion de pesos de las peticiones
5 Floats para 100 hasta 500kg
La suma de los 5 debe ser igual a 1.

Linia 5 : Distribucion de las horas de entrega
10 Floats para 8h hasta 17h
La suma de los 10 debe ser igual a 1.

IMPORTANTE : La separacion entre la parte entera y decimal puede ser una coma (,) o un punto (.), si sale un error "formato no valido", intenta cambiar eso.
