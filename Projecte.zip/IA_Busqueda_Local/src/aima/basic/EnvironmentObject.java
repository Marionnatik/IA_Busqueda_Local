package aima.basic;

public abstract class EnvironmentObject extends ObjectWithDynamicAttributes {

	/**
	 * @author Ravi Mohan
	 * 
	 */

	/*
	 * This represents any physical NON-AGENT object that can appear in an
	 * Environment.
	 */

}