package aima.basic;

public class BasicEnvironmentView {

	/**
	 * @author Ravi Mohan
	 * 
	 */

	public void envChanged(String command) {
		System.out.println(command);

	}

}