package aima.probability;

/**
 * @author Ravi Mohan
 * 
 */

public interface Randomizer {
	public double nextDouble();
}
