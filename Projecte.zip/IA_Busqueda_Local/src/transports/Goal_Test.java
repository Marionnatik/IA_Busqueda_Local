package transports;

import aima.search.framework.GoalTest;

public class Goal_Test implements GoalTest {

	@Override
	public boolean isGoalState(Object state) {
		return false;
	}

}
