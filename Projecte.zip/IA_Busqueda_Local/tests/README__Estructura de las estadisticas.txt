Fichero de input
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo

Fichero de input
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo
Tiempo inicial;Nodos expandidos;Beneficio final;Mejoramiento beneficio;retraso final; Mejoramento retraso;Tiempo algoritmo

