Linia 1 : Numero de tests
1 Integer

Linia 2 : Estrategia para generar el estado inicial
(Char)

Linia 3 : Tipo de algoritmo
(String)
Puede ser "hc" o "sa".

Linia 4 : Tipo de heuristica
(String)
Puede ser "gan" o "ret"

Linia 5: Parametros de el simulated annealing (solo se algoritmo SA)
3 Integer 1 Double


IMPORTANTE : La separacion entre la parte entera y decimal puede ser una coma (,) o un punto (.), si sale un error "formato no valido", intenta cambiar eso.
